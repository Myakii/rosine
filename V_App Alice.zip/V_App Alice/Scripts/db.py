from my_app import mysql

#Script pour créer bdd et tables

cur = mysql.connection.cursor()

cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    )
""")

mysql.connection.commit()
cur.close()

